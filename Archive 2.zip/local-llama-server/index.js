const { spawn } = require('child_process');
const axios = require('axios');
const chalk = require('chalk');
const cloudflaredPath = require('cloudflared').bin;

// Configuration
const OLLAMA_PORT = 11434;
const OLLAMA_HOST = 'http://127.0.0.1';

console.log(chalk.cyan('🚀 Initializing Local Llama Server (powered by Cloudflare)...'));

async function checkOllamaStatus() {
    try {
        console.log(chalk.yellow('⏳ Checking if Ollama is running...'));
        const response = await axios.get(`${OLLAMA_HOST}:${OLLAMA_PORT}/api/tags`);
        if (response.status === 200) {
            console.log(chalk.green('✅ Ollama is running locally!'));
            return true;
        }
    } catch (error) {
        console.log(chalk.red('❌ Could not connect to Ollama.'));
        console.log(chalk.gray(`   Error: ${error.message}`));
        console.log(chalk.yellow('💡 Tip: Make sure Ollama is running ("ollama serve").'));
        return false;
    }
}

async function startTunnel() {
    const isRunning = await checkOllamaStatus();

    if (!isRunning) {
        console.log(chalk.yellow('⚠️  Starting tunnel anyway, but requests will fail until Ollama is active.'));
    }

    console.log(chalk.cyan('🌐 Opening secure Cloudflare tunnel...'));

    // Spawn cloudflared process
    const tunnel = spawn(cloudflaredPath, [
        'tunnel',
        '--url',
        `${OLLAMA_HOST}:${OLLAMA_PORT}`
    ]);

    tunnel.stderr.on('data', (data) => {
        const output = data.toString();
        // Look for the URL in the output
        const urlMatch = output.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);

        if (urlMatch) {
            const publicUrl = urlMatch[0];
            console.log(chalk.green('\n🎉 Tunnel Established! (No Password Required)'));
            console.log(chalk.white('--------------------------------------------------'));
            console.log(chalk.bold.white('🔗 Public URL: ') + chalk.bold.blue(publicUrl));
            console.log(chalk.white('--------------------------------------------------'));
            console.log(chalk.yellow('📝 Update your WordPress settings:'));
            console.log(chalk.white('   1. Go to "AI Chatbot" -> "Settings"'));
            console.log(chalk.white('   2. Set "Private Ollama URL" (or Remote URL) to this link.'));
            console.log(chalk.white('   3. Save.'));
            console.log(chalk.white('--------------------------------------------------'));
            console.log(chalk.gray('Press Ctrl+C to stop.'));
        }
        // console.log(chalk.gray(output)); // Optional: uncomment for debug
    });

    tunnel.on('close', (code) => {
        console.log(chalk.red(`Tunnel process exited with code ${code}`));
    });
}

startTunnel();
